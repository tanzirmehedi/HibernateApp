package com.mbstu.entity;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.Iterator;
import java.util.List;

/**
 * Created by Shawon on 5/10/17.
 */
public class ListExample {

    public static void main(String[] args) {
        Session session = Connector.getSession();

        try{

        session.beginTransaction();
        List<Student> studentList = session.createQuery("FROM Student").list();

        for(Student student: studentList){
            System.out.println(student);
        }

    }catch (HibernateException e) {
            System.out.println("ERROR:"+e.getMessage());
    }
    }
}

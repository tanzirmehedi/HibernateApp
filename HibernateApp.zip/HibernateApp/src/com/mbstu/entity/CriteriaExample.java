package com.mbstu.entity;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import java.util.List;

/**
 * Created by Shawon 5/10/17.
 */
public class CriteriaExample {

    public static void main(String[] args) {
        Session session = Connector.getSession();

        try{

            session.beginTransaction();
            Criteria cr = session.createCriteria(Student.class);
            cr.add(Restrictions.gt("id", 3l));


            cr.addOrder(Order.desc("id"));

            List<Student> studentList = cr.list();

            for(Student student: studentList){
                System.out.println(student);
            }

        }catch (HibernateException e) {
            System.out.println("ERROR:"+e.getMessage());
        }
    }
}
